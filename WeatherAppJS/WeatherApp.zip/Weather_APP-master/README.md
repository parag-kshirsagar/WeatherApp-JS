# Weather_APP
It is used to predict the conditions of the atmosphere for a given location and time. It automatically searches for your address and show the weather condition.
